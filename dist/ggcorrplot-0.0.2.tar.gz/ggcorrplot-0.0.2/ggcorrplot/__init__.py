# -*- coding: utf-8 -*-
from __future__ import absolute_import

from .ggcorrplot import *

name = "fanalysis"
__version__ = "0.0.2"